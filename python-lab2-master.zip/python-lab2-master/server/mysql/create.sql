CREATE TABLE creds(username TEXT, password TEXT);
