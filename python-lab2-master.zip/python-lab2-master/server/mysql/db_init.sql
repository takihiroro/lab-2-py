use proj;

CREATE TABLE creds(username TEXT, password TEXT);
INSERT INTO creds VALUES('felix', '133737')   ;
INSERT INTO creds VALUES('felix', '100')    ;
INSERT INTO creds VALUES('felix', '1000')     ;
INSERT INTO creds VALUES('felix', '10000')    ;
INSERT INTO creds VALUES('felix', '100000')    ;
INSERT INTO creds VALUES('felix', '555')     ;
INSERT INTO creds VALUES('felix', '5555')     ;
INSERT INTO creds VALUES('felix', '55555')     ;
INSERT INTO creds VALUES('felix', '555555')     ;
/*INSERT INTO creds VALUES('felix', '10000')    ;
INSERT INTO creds VALUES('felix', '100000')   ;
INSERT INTO creds VALUES('felix', '1000000')  ;
INSERT INTO creds VALUES('felix', '10000000') ;
*/
INSERT INTO creds VALUES('felix', '999')     ;
INSERT INTO creds VALUES('felix', '9999')     ;
INSERT INTO creds VALUES('felix', '99999')    ;
INSERT INTO creds VALUES('felix', '999999')    ;
/*INSERT INTO creds VALUES('felix', '999999')   ;
INSERT INTO creds VALUES('felix', '9999999')  ;
INSERT INTO creds VALUES('felix', '99999999') ;
*/
