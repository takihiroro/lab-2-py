<h1> PRIVET</h1>

<form action="/login.php" method="post">
	<input type="text" name="user">
	<input type="password" name="password">
	<input type="submit">
</form>

